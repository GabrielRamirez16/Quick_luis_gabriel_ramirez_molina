<?php

if (isset($_POST["añadir_usuario"])) {


	

}


?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registro Formulario</title>
</head>
<body>
	 
	 <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

  <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
  <script>
    $(document).on('ready', function() {
      $('#show-hide-passwd').on('click', function(e) {
        e.preventDefault();
        var current = $(this).attr('action');
        if (current == 'hide') {
          $(this).prev().attr('type','text');
          $(this).removeClass('glyphicon-eye-open').addClass('glyphicon-eye-close').attr('action','show');
        }
        if (current == 'show') {
          $(this).prev().attr('type','password');
          $(this).removeClass('glyphicon-eye-close').addClass('glyphicon-eye-open').attr('action','hide');
        }
      })
    })
  </script>


  <div class="row">
    <div class="panel panel-default">
      <div class="panel-heading" style="background: #0174DF;">
        <strong>
          <span class="glyphicon glyphicon-user" style="color: #FFF;"></span>
          <span style="color: #FFF;">Formulario de Registro</span>
       </strong>
        </div>

      <div class="panel-body">
        <div class="col-md-6">
          <form method="post" action="conexion.php">

            <div class="form-group">
                <label for="Nombre">Nombre</label>
                <input type="text" class="form-control" name="Nombre" placeholder="Nombre completo" required>
            </div>

            <div class="form-group">
                <label for="Apellido">Apellido</label>
                <input type="text" class="form-control" name="Apellido" placeholder="Apellidos Completos">
            </div>


            <div class="form-group">
                <label for="Direccion">Dirección</label>
                <input type="text" class="form-control" name="Direccion" placeholder="Dirección">
            </div>

            <div class="form-group">
                <label for="Telefono">Telefono</label>
                <input type="text" class="form-control" name="Telefono" placeholder="Telefono">
            </div>


          

            <div class="form-group">
              <label for="Genero">Genero</label>
                <select class="form-control" name="Genero">
                	<option value="">    </option>
                	 <option value="1">Masculino</option>
                	 <option value="2">Femenino</option>
                  
                   
                
                </select>
            </div>


             <div class="form-group">
                <label for="Descripción">Descripción</label>
                <input type="text" class="form-control" name="Descripcion" placeholder="Escriba descripción">
            </div>

            


            <div class="form-group clearfix">
              <button type="submit" name="añadir_usuario" class="btn btn-primary" style="font-size: 18px;">Enviar</button>
              
            </div>
            </form>
</body>
</html>
