<?php
$conexion = mysqli_connect("localhost","root","","QuickL");





 $Nombre = $_POST['Nombre'];
 $Apellido = $_POST['Apellido'];
 $Telefono  = $_POST['Telefono'];
 $Genero = $_POST['Genero'];
 $Descripcion  =$_POST['Descripcion'];





$resultado = mysqli_query($conexion,"insert into usuario (nombre, apellido, telefono, genero, descripcion) VALUES ('$Nombre', '$Apellido', '$Telefono','$Genero','$Descripcion')");

	if ($resultado) {
		echo "Lo logro señor";
	}
	else{

		echo "Datos invalidos";
	}






?>
<div class="form-group clearfix">
              
              <a href="index.php"  style="font-size: 18px;">Regresar</a>
            </div>